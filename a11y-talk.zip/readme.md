# Зачем вам нужен доступный сайт или, как показать сайт незрячему? #

Презентация находится в трёх вариантах — с первым я выступал 15 минут на
встрече [FrontTalks](http://fronttalks.github.com/), со вторым я выступал примерно 40 минут на [UWDC](http://2013.uwdc.ru/).

Окончательный вариант более полный и предполагается, что у меня нет возможности
устно комментировать всё, что я написал в слайдах. Все варианты можно
[скачать](http://matmuchrapna.github.com/a11y-2013/a11y-talk.zip) одним архивом.


* [Окончательная полная презентация](http://matmuchrapna.github.com/a11y-2013/)
* [UWDC презентация](http://matmuchrapna.github.com/a11y-2013/index - UWDC.html)
* [FrontTalks презентация](http://matmuchrapna.github.com/a11y-2013/index - FrontTalks.html)
* [Скачать всю презентацию одним файлом](http://matmuchrapna.github.com/a11y-2013/a11y-talk.zip)

---------------------------------------

Презентация сделана на движке [Shower](https://github.com/shower/) и я благодарен [Вадиму Макееву](http://twitter.com/pepelsbey) за это.

